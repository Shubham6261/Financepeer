## FINANCEPEER CODING ASSIGNMENT

**ZIA BASHIR B.Tech CSE**

WEB FRAMEWORK - FLASK  

DATABASE SERVICE - MySQL  

FRONTEND - Bootstrap

**Installation :**

pip install flask-mysql  

python3 server.py

**Link to Video**  

Link to video : https://drive.google.com/file/d/1vNPBbM0zWXVK8CFp06HaaE9Vih0Z3STA/view?usp=sharing

**Keynotes:**
Json file must be present in the root directory  

If video is not loading please try downloading it.
